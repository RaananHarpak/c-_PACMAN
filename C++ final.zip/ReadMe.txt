Student:
Raanan Harpak 315816983
Sherry Mashavi 315234930

Description:
the steps file should be in this format:
the first line describe the fruit start point(is random).
(e.g - Fruit random point is :3 10, the value is:7)
the order of moves: pacman,fruit and ghosts
one oteration only pacman moves
the other itereation is pacman,fruit and ghosts.(for make the pacman faster).
when the fruit is not visible there is line : fruit is invisible for the valid order.
the number of step files is same as the number of screen files.
the valid argument is:
no arg-"simple" mode
-save 
-load
[-silent]
Thank you.